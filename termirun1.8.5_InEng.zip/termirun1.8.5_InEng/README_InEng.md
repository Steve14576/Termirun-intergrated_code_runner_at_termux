# termirun1.8.2

A multi-language compilation and execution tool designed specifically for Termux, enabling easy compilation and running of C, C++ and Java programs on Android devices.

Wait, calm down. You're not a primitive. If you don't know something, ask AI, and ask multiple times.

If you're a beginner, you should patiently read through the readme and check line 47.


## Features

- Supports compiling and running C, C++ and Java files
- Two running modes: detailed mode (outputs complete information) and simple mode (outputs concise information)
- Temporary execution mode, allowing running files from any path without changing configurations
- Quick mode, enabling 50 prefix-free command calls per session
- Automatic compiler installation and environment setup
- Configurable source code and compilation output directories
- Directory browsing functionality
- Automatic cleaning of invalid compilation products
- Instance management (uninstallation, deinitialization)


## Precautions Before Use

- For non-root users, please place termirun in Termux's default ~/ directory. Otherwise, termirun will definitely not have execution permissions.
- When transferring from Windows to Android, check for an extra .sh extension (which would make the full name termirun.sh.sh). If present, rename to remove the explicit .sh, otherwise it won't run.
- The display name of the termirun script on Android must be exactly "termirun" - no other name will work.
- Recommended for use with Termux, MT Manager, Acode, and Acodex-Terminal.
- Each termirun script can only handle code files in one specified folder (source file folder), either in the immediate subdirectory or through recursive searching.
- Each termirun script can switch its bound source file folder midway.
- You can also use multiple termirun scripts to bind to multiple source file folders. Note that different instances should be placed in different directories to avoid conflicts.
- When copying termirun for reuse, remember to deinitialize to clean up residual information and prevent conflicts (first copy to an isolated file path, then deinitialize in the new termirun).
- Temporary mode allows running a single code file from any path without changing configurations.


## Usage Method

1. Download the `termirun` script
2. Place it in your desired working directory in Termux (non-root users must place it within termux's built-in ~/ directory, otherwise execution permissions will be denied)
3. Grant execution permissions: `chmod +777 termirun`
4. Run: `./termirun` (this will start the initial setup)


## Nanny-Level Usage Guide for Non-Root Users and Absolute Beginners

0. If you encounter any problems during configuration, you can show this guide to AI for assistance. If you're taking photos with your phone, gently shake the camera when pressing the shutter to prevent moiré patterns.

1. Download the `termirun` script, Termux, Acode, and optionally Acodex-Terminal (a plugin for Acode that embeds a terminal in Acode, eliminating the need to switch between Acode and Termux - beginners can ignore this as it's not essential). (True beginners who can't use a VPN should ask AI where to download these - they're usually available on phone app stores and KuAn. Those who can use a VPN can find the corresponding .apk files on official websites or GitHub.)

2. Open the obtained termirun script with MT Manager and copy the current storage path of termirun displayed in the upper right corner (e.g., /A/B/C/termirun)

3. Open Termux or Acodex-Terminal and use the cd command to navigate to termirun's storage path (e.g., enter cd /A/B/C...... /termirun then press Enter)

3. Use the mv command to move termirun (without changing the name) to a "workstation folder" under ~/ where you want termurun to work (~ is a path in termux with unrestricted execution permissions - even without root, files under ~ can get execution permissions with chmod +777). (e.g., enter mv termirun ~/D/E/F....../workstation-folder/termirun) (The end of the path in the mv command is the new name. If the previous termirun script was named termirun.sh, just write termirun at the end of the mv command path.)

4. Use the cd command to open the "workstation folder" where termurun will work (e.g., enter cd ~/D/E/F....../workstation-folder then press Enter). (You can enter ls then press Enter to check if termirun exists - if it does, you're good.)

5. In this "workstation folder", use the chmod command to give termirun execution permissions (enter chmod +777 termirun)

6. Run termirun in this "workstation folder" and follow the wizard to complete initialization. You'll need to reserve a location for programming source files and a location for compilation products. Don't choose a location under ~/ because ~ has special permissions, and unrooted Android devices can't access ~ in Acode. Don't worry - termirun will find your files by navigating through several directories above and below ~/. (Enter ./termirun)

7. After initialization, you can use all features of termirun. All commands must be prefixed with ./ (e.g., enter ./termirun help and press Enter, not termirun help and press Enter). (Except after entering ./termirun go50 and pressing Enter to enable go50, where you can directly enter cucumber file.c and press Enter without ./termirun.)

8. After exiting and re-entering, termirun may close, but steps 1-5 and termirun's initialization are permanent. Just cd to your "workstation folder" and enter ./termirun again (step 4, then step 6).

9. Step 7 is very important. I will read step 7 again.


## Initial Setup

When you run termirun for the first time, you'll go through the following semi-automatic setup process guided by a wizard:
1. Environment variable check
2. View help information
3. Compiler environment check and installation
4. Configure compilation output directory
5. Configure source code directory


## Basic Commands

| Command | Description |
|---------|-------------|
| `termirun bins` | Set compilation output directory |
| `termirun carrot` | Set source code directory |
| `termirun cucumber <filename>` | Run in detailed mode (using configured directories) |
| `termirun cucumber t <file path>` | Run temporarily in detailed mode (any path) |
| `termirun cub <filename>` | Run in simple mode (using configured directories) |
| `termirun cub t <file path>` | Run temporarily in simple mode (any path) |
| `termirun compilers` | Check and install required compilers |
| `termirun clean` | Manually clean invalid compilation products |
| `termirun uninstall` | Completely uninstall the current instance |
| `termirun uninit` | Deinitialize (retains compilation products) |
| `termirun help` | Display help information |
| `termirun --version` | Display version information |
| `termirun go50` | Enter quick mode (50 prefix-free calls) |
| `termirun ls` | Browse directory structure (having tree is better, but not required) |
| `termirun oo` | View details of the previous command (cub or cucumber) |
| `termirun kk` | Repeat the previous command (cub or cucumber) for continuous debugging of the same file |


## Quick Mode

Run `termirun go50` to enter quick mode, allowing 50 prefix-free calls:
- `cub <filename>`: Simple mode
- `cub t <file path>`: Simple temporary mode
- `cucumber <filename>`: Detailed mode
- `cucumber t <file path>`: Detailed temporary mode
- `oo`: View previous step
- `kk`: Repeat previous step
Enter `q` at any time to exit quick mode.
