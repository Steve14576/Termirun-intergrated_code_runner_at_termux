# termirun1.8.2

一个多语言编译运行工具，专为Termux设计，可在Android设备上轻松编译和运行C、C++和Java程序。
停，冷静，你不是原始人，不会的问ai，多问几遍
如果我是小白我会耐心地把readme过一遍读然后看第47行



## 功能特点

- 支持编译和运行C、C++和Java文件
- 两种运行模式：详细模式（输出完整信息）和简单模式（输出精简信息）
- 临时执行模式，可运行任意路径的文件而不改变配置
- 快速模式，每个会话允许50次无前缀命令调用
- 自动编译器安装和环境设置
- 可配置源代码和编译输出目录
- 目录浏览功能
- 自动清理无效编译产物
- 实例管理（卸载、反初始化）




## 用前须知

- 对于非root用户，请将termirun放在Termux的默认~/目录之下的位置，否则termirun一定无权执行
- 从Windows传输到Android时，检查是否有多余的.sh扩展名(全称变为termirun.sh.sh)，有则重命名删掉显式的.sh，否则无法运行
- termirun脚本在安卓的显示名称是且仅能是termirun，否则无法运行
- 建议与Termux、MT管理器、Acode、Acodex-Terminal配合使用
- 每个temirun脚本只能同时负责一个指定的文件夹(源文件文件夹)中，或下一级裸露，或递归向下搜索，的代码文件的编译与运行
- 每个temirun脚本可以中途切换绑定的源文件文件夹
- 你也可以用多个termirun脚本分别绑定多个源文件文件夹，注意不同的实例应放在不同的目录中，以避免冲突
- 复制termirun并复用时，记得反初始化，清理残留信息避免冲突(先复制到一个隔离的文件路径再在新的termirun中反初始化)
- 临时模式允许从任何路径运行单个代码文件，而不改变配置



## 使用方法

1. 下载`termirun`脚本
2. 将其放在Termux中您想要的工作目录(非root用户要放在termux自带的~/目录下的位置，否则一定无权执行)
3. 赋予执行权限：`chmod +777 termirun`
4. 运行：`./termirun`（这将启动初始设置）



## 就算你没有root并且是小白的保姆级使用方法啊啊啊啊啊啊啊啊啊啊啊啊啊啊啊啊啊啊啊啊啊啊啊啊啊啊啊啊

0. 配置过程遇到任何问题，你可以把这里拍给ai让它解答，如果你真用手机拍，按快门的时候轻晃一下镜头，可以防止摩尔纹

1. 下载`termirun`脚本，Termux，Acode，*Acodex-Terminal(可选项，Acode的插件，可以在Acode中内置一个终端，不用反复在Acode和Termux切屏，真小白请忽略，没它不影响)（真小白且不会加速器的，去问ai去哪里下，手机自带应用商店和酷安一般都有收录，会加速器的，在对应官网或者github找对应的.apk）

2. 将获取到的termirun脚本用MT管理器打开，复制右上方显示的当前termirun的存放路径  （如/A/B/C/termirun）

3. 打开Termux或Acodex-Terminal的终端，用cd命令打开termirun的存放路径 （如输入cd /A/B/C...... /termirun然后回车）

3. 用mv命令将termirun移动为termirun(不要改名字)到~/下的一个你打算让termurun工作的"工位文件夹"（~是termux自带的一个执行权限没有被锁死的路径位置，就算没有root，在~之下的文件通过chmod +777也可以获得执行权限） （如输入mv termirun ~/D/E/F....../工位文件夹/termirun）（mv命令的路径最末端是“移动为的新名称”，如果之前的termirun脚本名称是termirun.sh，则在mv命令路径的末端写termirun即可）

4. 用cd命令打开termurun工作的"工位文件夹" （如输入cd ~/D/E/F....../工位文件夹 然后回车）（可以输入ls 然后回车看有无termirun，有就行）

5. 在这个"工位文件夹"中用chmod命令给termirun赋予执行权限 （输入chmod +777 termirun）

6. 在这个"工位文件夹"中运行termirun并跟随向导完成初始化，你会需要预留一个存放编程原文件的地方和一个存放编译产物的地方，不要选~/下面，因为~的权限特别高，未root的安卓设备在Acode上无法访问~，这意味着你的放心，termirun会从~/下面横跨好几个目录上上下下地找到你的文件的              （输入./termirun）

7. 初始化完成后即可使用termirun的全部功能，前面全都要加./，（如输入./termirun help回车，而不是输入termirun help回车，）         （除了输入./termirun go50 回车打开go50之后，可以无./termirun地直接输入cucumber file.c 回车）

8. 退出重进之后可能会退出termirun，但1.到5.以及termirun的初始化的工作是永久的，你再cd到"工位文件夹"中输入./termirun即可 （第4.步，然后第6.步）

9. 第7.步很重要，我会再看一遍第7.步



## 初始设置

首次运行termirun时，您将在向导下经历以下半自动设置过程：
1. 环境变量检查
2. 查看帮助信息
3. 编译器环境检查和安装
4. 配置编译输出目录
5. 配置源代码目录



## 基本命令

| 命令 | 描述 |
|------|------|
| `termirun bins` | 设置编译输出目录 |
| `termirun carrot` | 设置源代码目录 |
| `termirun cucumber <文件名>` | 以详细模式运行（使用配置的目录） |
| `termirun cucumber t <文件路径>` | 以详细模式临时运行（任意路径） |
| `termirun cub <文件名>` | 以简单模式运行（使用配置的目录） |
| `termirun cub t <文件路径>` | 以简单模式临时运行（任意路径） |
| `termirun compilers` | 检查并安装所需的编译器 |
| `termirun clean` | 手动清理无效的编译产物 |
| `termirun uninstall` | 完全卸载当前实例 |
| `termirun uninit` | 反初始化（保留编译产物） |
| `termirun help` | 显示帮助信息 |
| `termirun --version` | 显示版本信息 |
| `termirun go50` | 进入快速模式（50次无前缀调用） |
| `termirun ls` | 浏览目录结构（你有tree更好没有不影响） |
| `termirun oo` | 查看上一步执行命令（cub或cucumber） |细节
| `termirun kk` | 重复上一步执行命令（cub或cucumber）用于同一个文件的连续调试 |




## 快速模式

运行`termirun go50`进入快速模式，允许50次无前缀调用：
- `cub <文件名>`: 简单模式
- `cub t <文件路径>`: 简单临时模式
- `cucumber <文件名>`: 详细模式
- `cucumber t <文件路径>`: 详细临时模式
- `oo`: 查看上一步
- `kk`: 重复上一步
随时输入`q`退出快速模式。



